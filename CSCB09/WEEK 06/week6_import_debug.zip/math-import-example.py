import math
# import math as m

# from math import ceil
# from math import ceil as c
# from math import *


# help(math)
# math.sqrt()
# math.pi

##########EXAMPLES##################
x = math.pi
y = math.sqrt(4)
z = math.ceil(4.22)

print(x, y, z)