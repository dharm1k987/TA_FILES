# step 1: basic import
import week6_import_a
print(week6_import_a.my_cool_function())

# step 2: giving it a better name


# part of step 2
# print(imp.my_cool_function())
# step 3 in other file

# part of step 4
# print("The name of week6_import_b is: ", __name__)

# step 5: show how main code can be hidden
'''
if(__name__ == "__main__"):
    print("week6_import_b.py is being run as the main file")
'''