def split_input(i):
    '''
    (str) -> list of str
    Return the upstream gene and downstream
    REQ: Strings have to be genes
    '''
    # find the location of ATG
    location = i.find("AGTAAG")
    length_of_seq = len("AGTAAG")
    
    # if it's not found, it's not there
    if (location < 0):
        return  [i, "", ""]
    
    # set up equal to i sliced from 0 to location
    up = i[0:location]
    # the result
    no_up = i[location:len(i)]
    
    # skip the ATG part
    no_up_no_atg = i[location + length_of_seq:len(i)]
    # find the next one
    location = no_up_no_atg.find("ATG")
    
    if (location > 0):
        # get the gene
        g = no_up[0:location + length_of_seq]
        after = no_up[location + length_of_seq:len(no_up)]
        return [up, g, after]
    
    else:
        # no downstream
        return [up, no_up, ""]
    
    
    
# docstring, examples, REQ: genes must be "ATG", "..."
# parameter bad variable names parameter i should be sequence
# one return statement
# better would be upstream rather then up
# more comments
# get rid of the magic numbers
