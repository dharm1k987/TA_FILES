x = 7
y = 10
x = 8
x = 10
x = 8
x = y
y = 15
z = x + y
print(z)
x = "Hello"
y = 5
#z = x + y <-- explain why this won't work
print(x * y) #<-- explain how since we didn't save the result of expression, it's now ‘lost'
