class Student():
    ''' A class for a UTSC student '''
    
    def __init__(self, name, age, student_num):
        ''' (Student, str, int, int) -> NoneType
        Initialize the student
        '''
        
        self._name = name
        self._age = age
        self._student_num = student_num
        # another class, set to empty list
        self._courses = []
        
    def __str__(self):
        ''' (Day) -> str
        Return a str repr of this student
        '''
        result = self._name + " " + str(self._age) + " "
        result += str(self._student_num)
        result += "\nIn courses: "
        
        for course in self._courses:
            result += str(course) + "\n"
            
        return result
    
    def add_course(self, course):
        ''' (Student, Course) -> NoneType '''
        self._courses.append(course)
    
class Course():
    ''' A class for Courses '''
    def __init__(self, name_of_course, enrollment):
        '''
        (Course, str, int) -> NoneType
        '''
        self._name_of_course = name_of_course
        self._enrollment = enrollment
        
    def __str__(self):
        '''
        (Course) -> str
        '''
        result = self._name_of_course + " : " + str(self._enrollment)
        return result
    
if __name__ == "__main__":
    s1 = Student("Bob", 18, 1003158764)
    c1 = Course("CSCA08", 956)
    s1.add_course(c1)
    print(s1)

                      
    