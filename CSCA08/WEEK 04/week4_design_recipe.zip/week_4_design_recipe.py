def student_data(name, age, student_no, is_in_a08):
    '''
    import doctest
    doctest.testmod()


    (str, int, str, bool) ->  str

    This function will take in a name, age, student_no, and whether or not
    they are enrolled in a08, and return a string formatted to show this.

    REQ: age >= 0

    >>> student_data("Brian", 30, "100", True)
    '<100,Brian,30,True>'

    >>> student_data("Bob", 10, "123", False)
    '<123,Bob,10,False>'
    '''

    # set up a string, with '<' symbol
    final = "<"

    # add student number, and comma
    # final = <student_no,
    final += student_no+","

    # add name followed by comma
    final += name+","

    # add age, followed by comma
    final += str(age)+","

    # add is_in_a08, followed by >
    final += str(is_in_a08)+">"

    # return final
    return final

# quiz next week
# design recipe
# examples first
# >>><space>(func)
# output right next line
# comments

# strs can only be added with strs, cast if otherwise, str + int = str+str(int)


# pep8 (pep8 online) (might fail now cause I have all these comments)
# re run doctest!



