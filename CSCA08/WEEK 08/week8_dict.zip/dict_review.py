# key: value
# name: age
# random order
# access via KEYS

# how to declare
result = {} # might be confusing with set
result2 = dict() # I prefer this
list_example = list()
set_example = set()

# draw on board
# set the key bob in result mapped to the value 19
result["bob"] = 19
print(result)

# another
result["carol"] = 20

# order might be different next time
print(result)

# set bob to something else
result["bob"] = 69

print(result)

# remove bob
del result["bob"]

# if you try to remove a key that doesn't exist, you will get an error

print(result)

# dict keys must be immutable (int, char, string), cannot be a list

# result[[1,2,3]] = "a" -> fails

# how to loop over
result2 = {"bob": 69, "carol": 15, "jim": 20}

sum_ages = 0

for key in result2:
    # we have the key (bob, carol, jim)
    sum_ages += result2[key]
    
print(sum_ages)

# not all keys have to be of same type, but they usually are
result2 = {"bob": 69, 5: 10, 8: "nine"}
print(result2)

# how to test
result2 = {"bob": 69, "carol": 20, "jim": 10, "pastry": 100}
# notice how the order is different but the result is still True
print(result2 == {"bob": 69, "pastry": 100, "jim": 10, "carol": 20})

